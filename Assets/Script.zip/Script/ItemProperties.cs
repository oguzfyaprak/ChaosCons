using UnityEngine;

public class ItemProperties : MonoBehaviour
{
    [HideInInspector] public bool OriginalKinematicState;
    public int ownerPlayerID; // Bu item kime ait
}